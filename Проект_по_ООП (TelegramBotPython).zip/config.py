TOKEN = "1444339635:AAEWaQQmfy-Guk47iioxwIDiT7lbL5h5z-I"
exchanges = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB'
}